package Unified_Test_Structure_Updated_test

import (
	"log"
	"testing"

	"fmt"

	fileHelper "Unified-Test-Structure_Updated/helpers"
	ruleHelper "Unified-Test-Structure_Updated/rules/response/udiServices/uploadAPI"
	helper "Unified-Test-Structure_Updated/services/beaconUDIServices"
	structHelper "Unified-Test-Structure_Updated/structures/response/udiServices/uploadAPI"

	logger "Unified-Test-Structure_Updated/logger"

	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
)

func TestUnifiedTestStructureUpdated(t *testing.T) {
	RegisterFailHandler(Fail)
	RunSpecs(t, "UnifiedTestStructureUpdated Suite")

}

var _ = Describe("Upload zip and ndi to s3", func() {

	Context("Call upload services", func() {

		BeforeEach(func() {
			logger.Log(logger.Infor, "Before Each Block")

		})

		logger.Log(logger.Infor, "Test Context Block")

		It("Call to upload file to S3", func() {})
		// response := services.Access_token_api_call("_DCVG8eIpxhBDAvm-6B83b_HfayOdI-kgEwQIyw8W58")
		// fmt.Println(response)
		// General method to read data from multiple extension file, just Pass the file name- (Which is inside resources package)
		// reader.ReadAll_File("./file_Json.json")

		//reader.ReadAll_File("./file_yaml.yaml")
		//reader.ReadAll_File("./file_Env.env")
		strUploadDataResp := helper.UploadBeaconData()
		resp1 := string(*strUploadDataResp)
		log.Println("upload service response is " + resp1)
		jsonObject := fileHelper.LoadJsonResponseToStruct(*strUploadDataResp, &structHelper.UploadapiResponseSuccessStruct{})
		fmt.Printf("jsonObject: %v\n", jsonObject)
		jsonResponse := fileHelper.StructToJson(jsonObject)
		fmt.Printf("jsonStringResponse: %v\n", jsonResponse)
		helper.DoverifySuccess(resp1)
		rules := ruleHelper.ValidateRule()
		log.Println(rules)
		ruleSatisfied := fileHelper.ResponseValidationWithRule(rules, jsonObject)
		fmt.Printf("Rule satisfied: %v\n", ruleSatisfied)
		Expect(ruleSatisfied).To(Equal(true))

	})
})

// BeforeSuite blocks are run just once before any specs are run.  When running in parallel, each
// parallel node process will call BeforeSuite.
var _ = BeforeSuite(func() {

})

// AfterSuite blocks are *always* run after all the specs regardless of whether specs have passed or failed.
// Moreover, if Ginkgo receives an interrupt signal (^C) it will attempt to run the AfterSuite before exiting.
var _ = AfterSuite(func() {

})
