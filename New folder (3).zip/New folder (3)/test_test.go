package test

import (
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"

	"fmt"
	"log"
	"testing"

	fileHelper "github.com/flexera/unified-pipeline-tests/unifiedpipelinetests/helpers"
	logger "github.com/flexera/unified-pipeline-tests/unifiedpipelinetests/logger"
	ruleHelper "github.com/flexera/unified-pipeline-tests/unifiedpipelinetests/rules/response/udiServices/uploadAPI"
	helper "github.com/flexera/unified-pipeline-tests/unifiedpipelinetests/services/beaconUDIServices"
	structHelper "github.com/flexera/unified-pipeline-tests/unifiedpipelinetests/structures/response/udiServices/uploadAPI"
)

func TestTest(t *testing.T) {
	RegisterFailHandler(Fail)
	RunSpecs(t, "Test Suite")
}

var _ = Describe("Upload zip and ndi to s3", func() {
	BeforeEach(func() {
		logger.Log(logger.Infor, "Before Each Block")
	})
	Context("Call upload services", func() {
		logger.Log(logger.Infor, "Test Context Block")
		It("Upload zip and ndi file to S3", func() {
			By("calling services of upload files  to place files into s3")
			strUploadDataResp := helper.UploadBeaconData()
			resp1 := string(*strUploadDataResp)
			log.Println("upload service response is " + resp1)
			jsonObject := fileHelper.LoadJsonResponseToStruct(*strUploadDataResp, &structHelper.UploadapiResponseSuccessStruct{})
			fmt.Printf("jsonObject: %v\n", jsonObject)
			jsonResponse := fileHelper.StructToJson(jsonObject)
			fmt.Printf("jsonStringResponse: %v\n", jsonResponse)
			helper.DoverifySuccess(resp1)
			rules := ruleHelper.ValidateRule()
			log.Println(rules)
			ruleSatisfied := fileHelper.ResponseValidationWithRule(rules, jsonObject)
			fmt.Printf("Rule satisfied: %v\n", ruleSatisfied)
			Expect(ruleSatisfied).To(Equal(true))
		})
	})

})

// BeforeSuite blocks are run just once before any specs are run.  When running in parallel, each
// parallel node process will call BeforeSuite.
var _ = BeforeSuite(func() {

})

// AfterSuite blocks are *always* run after all the specs regardless of whether specs have passed or failed.
// Moreover, if Ginkgo receives an interrupt signal (^C) it will attempt to run the AfterSuite before exiting.
var _ = AfterSuite(func() {

})
