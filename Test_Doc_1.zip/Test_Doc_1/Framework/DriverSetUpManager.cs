﻿using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsInput.Native;
using WindowsInput;

namespace FlexeraAppPortal.Framework
{
    public class DriverSetUpManager
    {
        public static IWebDriver? driver = null;
        private static ICapabilities? capabilities;
        public static string Browser = "";
        public static string Username = "\"appportal\\\\appportal\"";
        public static string Password = "\"Flexera!\"";
        public static string URL = "http://10.75.205.122/esd/";

        public static void DriverSetup()
        {

            switch (Browser)
            {
                case "Chrome":
                    ChromeOptions options = new ChromeOptions();
                    driver = new ChromeDriver(options);
                    capabilities = ((ChromeDriver)driver).Capabilities;
                    break;
                case "Firefox":
                    FirefoxOptions options1 = new FirefoxOptions();
                    driver = new FirefoxDriver(options1);
                    capabilities = ((FirefoxDriver)driver).Capabilities;
                    break;
                case "Edge":
                    EdgeOptions options2 = new EdgeOptions();
                    driver = new EdgeDriver(options2);
                    capabilities = ((EdgeDriver)driver).Capabilities;
                    break;
                default:
                    ChromeOptions options3 = new ChromeOptions();
                    driver = new ChromeDriver(options3);
                    capabilities = ((ChromeDriver)driver).Capabilities;
                    break;

            }
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);

            Thread.Sleep(3000);
            // Testing URL
            driver.Navigate().GoToUrl(URL);
        }

        public static void LoginSetUp()
        {
            InputSimulator inputSim = new InputSimulator();
            Thread.Sleep(3000);
            // Enter username
            inputSim.Keyboard.TextEntry(Username);
            Thread.Sleep(1000);
            // press Tab key 
            inputSim.Keyboard.KeyPress(VirtualKeyCode.TAB);
            Thread.Sleep(1000);
            // Enter Password 
            inputSim.Keyboard.TextEntry(Password);
            Thread.Sleep(4000);
            // Click on Sign In button 
            inputSim.Keyboard.KeyPress(VirtualKeyCode.RETURN);
            Thread.Sleep(15000);
            Assert.True(driver.Title.Contains("Flexera Software App Portal"));
        }

    }
}
