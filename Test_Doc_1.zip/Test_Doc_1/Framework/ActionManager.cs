﻿using ICSharpCode.SharpZipLib.Zip;
using NUnit.Framework;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexeraAppPortal.Framework
{
    public class ActionManager
    {
        public static string browser = "";
        public static string baseUrl = "";

        #region CoreOverriddenMethods
        // WaitManager wait = new WaitManager();
        public string basewindowhandle = DriverSetUpManager.driver.CurrentWindowHandle;
        public void Click(IWebElement element)
        {

           // wait.UntilIsElementIsClickable(element);
            try
            {
                element.Click();
            }
            catch (StaleElementReferenceException)
            {
                // Retry only if selenium throws element no longer valid exception due to stalenes of element
                element.Click();
            }
            catch (InvalidOperationException)
            {
                //Chrome Retry if unable to click because of overlapping (Chrome NativeEvents is always on (Clicks via Co-ordinates))
                //Thread.Sleep(pauseTimeInSeconds * 3);
                Thread.Sleep(5000);
                JavaScriptClick(element);
            }
        }

        public void JavaScriptClick(IWebElement element)
        {
            try
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)DriverSetUpManager.driver;
                executor.ExecuteScript("arguments[0].click();", element);
            }
            catch (Exception)
            {
            }
        }

        public void ClickByReference(IWebElement ReferenceElement, By ActionLocator)
        {
            ReferenceElement.FindElement(ActionLocator).Click();
        }

        public void HoverAndClick(IWebElement element)
        {
            Actions actions = new Actions(DriverSetUpManager.driver);
            actions.MoveToElement(element);
            actions.Click().Perform();
            actions.Release().Perform();
        }

        public void Hover(IWebElement element)
        {
            Actions actions = new Actions(DriverSetUpManager.driver);
            switch (browser)
            {
                case "Chrome":
                    IAction mouseOverHome = actions.MoveToElement(element).Build();
                    mouseOverHome.Perform();
                    break;

                case "InternetExplorer":
                default:
                    actions.MoveToElement(element);
                    actions.Build().Perform();
                    break;

            }
        }

        public void JavascriptExecutor(IWebElement element, string javascript)
        {
            ((IJavaScriptExecutor)DriverSetUpManager.driver).ExecuteScript(javascript, element);
        }
        public void DismissAlert()
        {
            IAlert alert = DriverSetUpManager.driver.SwitchTo().Alert();
            alert.Dismiss();
        }

        public void AcceptAlert()
        {
            IAlert alert = DriverSetUpManager.driver.SwitchTo().Alert();
            alert.Accept();
        }

        public Boolean IsAlertPresent()
        {
            try
            {
                DriverSetUpManager.driver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        public void SelectElementByText(IWebElement element, string text)
        {
            new SelectElement(element).SelectByText(text);
        }

        public void SelectElementByValue(IWebElement element, string value)
        {
            new SelectElement(element).SelectByValue(value);
        }

        public int SelectElementOptionCount(IWebElement element)
        {
            SelectElement GroupSelect = new SelectElement(element);
            var OptionCount = GroupSelect.Options.Count;
            return OptionCount;
        }

        public void SendKeys(IWebElement element, string text)
        {
            Clear(element);
            element.SendKeys(text);
            //var wait = new WaitManager();
            // wait.ForDocumentToBeReady();
        }

        public void Clear(IWebElement element)
        {
            element.Clear();
        }

        /// <summary>
        /// Alternate for clear method
        /// </summary>
        public void RemoveValues(IWebElement element)
        {
            element.SendKeys(Keys.Control + "a");
            element.SendKeys(Keys.Backspace);
        }

        public void NavigateToUrl(string relativeUrl)
        {
            //wait.ForDocumentToBeReady();
            DriverSetUpManager.driver.Navigate().GoToUrl(baseUrl + relativeUrl);
            //wait.ForDocumentToBeReady();
        }

        public void Refresh()
        {
            DriverSetUpManager.driver.Navigate().Refresh();
        }

        public string GetCurrentURL()
        {
            return DriverSetUpManager.driver.Url;
        }
        #endregion


        #region HandlingComplexEvents

        public void DragAndDrop(IWebElement From, IWebElement To)
        {
            Actions actions = new Actions(DriverSetUpManager.driver);
            actions.DragAndDrop(From, To).Build().Perform();
        }
        public void OpenNewTab()
        {
            DriverSetUpManager.driver.FindElement(By.CssSelector("body")).SendKeys(Keys.Control + "t");
            int count = DriverSetUpManager.driver.WindowHandles.ToList().Count;
            DriverSetUpManager.driver.SwitchTo().Window(DriverSetUpManager.driver.WindowHandles[count]);
        }
        public IWebElement GetElement(By Locator)
        {
            return DriverSetUpManager.driver.FindElement(Locator);
        }

        public string GetAttributeValue(IWebElement element)
        {
            return element.GetAttribute("value");
        }

        public string GetElementText(IWebElement element)
        {
            return element.Text;
        }

        /// <summary>
        /// Get all options into the list
        /// </summary>
        public static List<string> GetAllOptionsIntoList(IList<IWebElement> rowItems)
        {
            List<string> listData = new List<string>();
            foreach (var item in rowItems)
            {
                listData.Add(item.Text.Trim().ToString());
            }

            return listData;
        }

        /// <summary>
        /// Get all values into the list
        /// </summary>
        public static List<string> GetAllValuesIntoList(IList<IWebElement> rowItems)
        {
            List<string> listData = new List<string>();
            foreach (var item in rowItems)
            {
                listData.Add(item.GetAttribute("value".ToString()));
            }

            return listData;
        }

        /// <summary>
        /// Select the value from the list
        /// </summary>
        public void SelectValueFromList(IList<IWebElement> listItems, string expectedData)
        {
            Thread.Sleep(750);
            for (int i = 0; i < listItems.Count(); i++)
            {
                string actualData = listItems[i].Text.Trim();
                if (actualData.Equals(expectedData))
                {
                    listItems[i].Click();
                    break;
                }
                else
                {
                    if (i.Equals(listItems.Count() - 1))
                    {
                        throw new Exception(string.Format("Expected option is missing"));
                    }

                    continue;
                }
            }
        }

        /// <summary>
        /// Get all grid data into list
        /// </summary>
        public static List<List<string>> GetAllGridDataIntoList(IList<IWebElement> rowItems, IList<IWebElement> ColumnItems)
        {
            Thread.Sleep(1000);
            List<List<string>> gridData = new List<List<string>>();

            if (rowItems.Count > 0)
            {
                string[] columnList = new string[(int)Math.Round((double)ColumnItems.Count / rowItems.Count)];
                int x = 0;
                for (int i = 0; i < rowItems.Count; i++)
                {
                    for (int j = 0; j < columnList.Count(); j++)
                    {
                        columnList[j] = ColumnItems[x].Text;
                        x++;
                    }

                    gridData.Add(new List<string>(columnList));
                }
            }

            return gridData;
        }

        /// <summary>
        /// Remove the Excel file from local path
        /// </summary>
        public static void RemoveFile(string fileName)
        {
            string userPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string downloadPath = Path.Combine(userPath, "Downloads");
            if (File.Exists(downloadPath + "\\" + fileName))
            {
                File.Delete(downloadPath + "\\" + fileName);
            }
        }

        public void SwitchToChildPopUp()
        {
            basewindowhandle = DriverSetUpManager.driver.CurrentWindowHandle;
            int count = DriverSetUpManager.driver.WindowHandles.ToList().Count;
            if (count == 1)
            {
                Assert.Fail("New browser not opened. Please check disable TURN ON POPUP BLOCKER");
            }
            while (--count >= 0)
            {
                if (basewindowhandle != DriverSetUpManager.driver.WindowHandles[count])
                {
                    // wait.ForDocumentToBeReady();
                    DriverSetUpManager.driver.SwitchTo().Window(DriverSetUpManager.driver.WindowHandles[count]);
                    DriverSetUpManager.driver.Manage().Window.Maximize();
                    break;
                }
            }
            Thread.Sleep(3000);
        }

        public void SwitchToBaseWindow()
        {
            DriverSetUpManager.driver.SwitchTo().Window(basewindowhandle);
            DriverSetUpManager.driver.Manage().Window.Maximize();
            Thread.Sleep(5000);
        }

        public void SwitchToFrame(IWebElement element)
        {
            DriverSetUpManager.driver.SwitchTo().Frame(element);
            Thread.Sleep(5000);
        }
      

        /// <summary>
        /// Extract the Zip file from local path
        /// </summary>
        public static void ExtractFile(string fileName)
        {
            FastZip fastZip = new FastZip();
            string fileFilter = null;
            string userPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string downloadPath = Path.Combine(userPath, "Downloads");
            if (File.Exists(downloadPath + "\\" + fileName))
            {
                fastZip.ExtractZip(downloadPath + "\\" + fileName, downloadPath, fileFilter);
            }
            else
            {
                throw new Exception(string.Format("Zip file not found"));
            }
        }
        #endregion
    }
}
