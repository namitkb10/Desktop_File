﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.CommonClass
{
    public class ClassCommon
    {
        /*IWebDriver driverFromRQPages;
        public ClassCommon(IWebDriver rDriver)
        {
            this.driverFromRQPages = rDriver;
            //PageFactory.
        }*/
        public string getDataFromFile(string abc)
        {
            bool flag = false;
            // string fileName = Path.GetFullPath("TestData\\testdatafile.txt");

            // Console.WriteLine("Root Path Check: " + root); 

            // String strFile = AppDomain.CurrentDomain.BaseDirectory + "TestData\\testdatafile.txt";


            string fileName = @"C:\Users\AppPortal\source\repos\SpecFlowBDD_22_12_June_New\SpecFlowBDD_22\SpecFlowBDD_22\TestData\testdatafile.txt";
            //var data = new Dictionary<string, string>();
            var dataFile = File.ReadAllLines(fileName);
            String dataReturn = "";
            foreach (var row1 in dataFile)
            {
                flag = false;
                // Console.WriteLine(row1);
                String[] strArr = row1.Split('=');
                if (strArr[0] == abc)
                {
                    // Console.WriteLine(strArr[0] + " is: " + strArr[1]);

                    flag = true;
                    dataReturn = strArr[1];
                }
                if (flag == true)
                {
                    break;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("Please enter valid key to get value");
            }
            return dataReturn;
        }



        public void UncheckAllBasicSearchTerm(IWebElement chkBoxBriefDescriptionSearch, IWebElement chkBoxFullDescriptionSearch, IWebElement chkBoxKeywordSearch)
        {
            /*if(chkBoxTitleSearch.Selected)
            {
                chkBoxTitleSearch.Click();
            }*/

            if (chkBoxBriefDescriptionSearch.Selected)
            {
                chkBoxBriefDescriptionSearch.Click();
            }

            if (chkBoxFullDescriptionSearch.Selected)
            {
                chkBoxFullDescriptionSearch.Click();
            }

            if (chkBoxKeywordSearch.Selected)
            {
                chkBoxKeywordSearch.Click();
            }
        }

        public void CheckBasicSearchTerm(IWebElement chkBoxBriefDescriptionSearch, IWebElement saveButton)
        {
            if(!chkBoxBriefDescriptionSearch.Selected)
            {
                chkBoxBriefDescriptionSearch.Click();
                saveButton.Click();
            }
        }

        
    }
}
