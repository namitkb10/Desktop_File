﻿using AventStack.ExtentReports.Model;
using Dynamitey.DynamicObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using SeleniumExtras.PageObjects;
using SpecFlowBDD_22.CommonClass;
using SpecFlowBDD_22.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.Pages
{
    public class RQ05_Pages
    {
        //ClassCommon cc

        RQ05_Pages rq05pages;
        public IWebDriver rq05Driver;
        string catalogClassificationType;
        public static string selectedTitleText;
        string parentWindowHandle;

        List<int> actualLinkListIndex;
        List<int> newSortedListIndex;

        [FindsBy(How = How.Id, Using = "//div[@data-classificationsort=\"0\"]")]
        public IWebElement _classificationSort { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rpText' and contains(text(),'Catalog Management')]")]
        public IWebElement _catalogManagement { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rpText' and contains(text(),'Current Catalog Items')]")]
        public IWebElement _currentCatalogItems { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rtIn' and contains(text(),'View All Items')]")]
        public IWebElement _viewAllItems { get; set; }

        // frame

        /*[FindsBy(How = How.XPath, Using = "//tr[@id='ctl00_cph1_Grid1_ctl00__2']/td[2]")]
        public IWebElement _captureTitleText { get; set; }*/

        //Clicking on third row
        /*[FindsBy(How = How.XPath, Using = "//tr[@id='ctl00_cph1_Grid1_ctl00__2']")]
        public IWebElement _doubleClickOn3rdRow { get; set; }*/

        [FindsBy(How=How.XPath, Using = "//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr")]
        public IList<IWebElement> _rowItemDetails { get; set; }

        /*[FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr/td[2]")]
        public IList<IWebElement> _columnDataItemDetails { get; set; }*/

        //Clicking on third row
        /*[FindsBy(How = How.XPath, Using = "//tr[@id='ctl00_cph1_Grid1_ctl00__6']")]
        public IWebElement _doubleClickOn6thRow { get; set; }*/

        //navigate to pop-up page

        // [FindsBy(How = How.XPath, Using = "//input[@id='ctl00_cph1_cbGlobalVisible']")]
        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_mpGeneral']//input[@id='ctl00_cph1_cbGlobalVisible']")]
        
        public IWebElement _chkBoxIsEnabled { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rtbIn']/span [text()='Save']")]
        public IWebElement _saveButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rtbIn']/span[text()='Archive']")]
        public IWebElement _archiveButton { get; set; }
        

        [FindsBy(How = How.XPath, Using = "//a[@class='rwCloseButton']")]
        public IWebElement _popUpPageCloseButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Successfully updated')]")]
        public IWebElement _saveMessagae { get; set; }


        

        //============================================================================




        //============================================================================

        public RQ05_Pages(IWebDriver rDriver)
        {
            rq05Driver = rDriver;
            PageFactory.InitElements(rDriver, this);
        }

        public void VerifyTheSearchResultBasedOnPreferredNonClassifiedNonpreferred()
        {

            IList<IWebElement> listWebElement = rq05Driver.FindElements(By.XPath("//div[@class='showcaseCardOuter']"));

            List<string> values = new List<string>();
            List<string> valuesCopy = new List<string>();
            foreach (WebElement el in listWebElement)
            {
                String value1 = el.GetAttribute("data-classificationsort");
                values.Add(value1);
                valuesCopy.Add(value1);
            }
            // IWebElement element = rq05Driver.FindElement(By.XPath("//div[@class='showcaseCardOuter']"));
            var flag = true;

            /*values.Add("2");
            valuesCopy.Add("1");*/

            valuesCopy.Sort();

            for (int i = 0; i < values.Count; i++)
            {
                if (values[i] != valuesCopy[i])
                {
                    flag = false;
                    break;
                }
            }

            if (flag == false)
            {
                throw new Exception(string.Format("Displayed Catalog Classification is not in expected order"));
                // Console.WriteLine("Displayed Catalog Classification is not in expected order");
            }

            /*List<string> listOfCatalogElement = null; ;
            List<string> newlistOfCatalogElement = null;
            var order = true;
            IList<IWebElement> listWebCatalogElement = rq05Driver.FindElements(By.XPath("//div[@class='showcaseCardOuter']"));

            foreach (var item in listWebCatalogElement)
            {
                String str = item.GetAttribute("data-classificationsort");

                listOfCatalogElement.Add(item.GetAttribute("data-classificationsort"));
                newlistOfCatalogElement.Add(item.GetAttribute("data-classificationsort"));
            }

            newlistOfCatalogElement.Sort();

            for(int i=0;i< listWebCatalogElement.Count;i++)
            {
                if (newlistOfCatalogElement[i] == listOfCatalogElement[i])
                {
                    order = false;
                    break;
                }
            }

            if (order == false)
            {
                throw new Exception(string.Format("Data is not in sorted order"));
            }*/

            /*//div[@class='showcaseCardOuter']
            int countClassificationSort;
            var alphabetical=true;
            string catalogClassificationType;
            List<string> actualLinkList = null;
            List<string> newSortedList;
            // int count = rq05Driver.FindElements(By.ClassName("showcaseCardOuter")).Count();

            for (int i=0; i<=2;i++)
            {

                IList<IWebElement> listWebElement = rq05Driver.FindElements(By.XPath("//div[@class='cataloglistonscroll" + i + "']"));

                

                actualLinkListIndex = new List<int>();
                newSortedListIndex = new List<int>();

                actualLinkListIndex.Add(i);
                newSortedListIndex.Add(i);

                newSortedListIndex.Sort();
                

                if (actualLinkList.Count > 1)
                {
                    alphabetical = true;
                    for (int j = 0; j < actualLinkList.Count - 1; j++)
                    {
                        if (actualLinkListIndex[i] != newSortedListIndex[i])
                        {
                            alphabetical = false;
                            break;
                        }
                    }
                }
                if (alphabetical==false)
                {
                    throw new Exception(string.Format("Data is not in sorted order"));
                }
            }*/
        }

        public void VerifyAllThePreferredNon_ClassifiedNon_PreferredCatalogItemsCatalogItemsShouldBeSortedAlphabeticallyInRespectiveClassifications()
        {
            var alphabetical = true;
            List<string> actualLinkList;
            List<string> newSortedList;


            for (int i = 0; i <= 2; i++)
            {

                IList<IWebElement> listWebElement = rq05Driver.FindElements(By.XPath("//div[@class='cataloglistonscroll" + i + "']//div[@class='showcaseCardTitle']"));
                actualLinkList = new List<string>();
                newSortedList = new List<string>();
                /*if(i==0)
                {
                    catalogClassificationType = "preferred";
                }
                else if (i == 1)
                {
                    catalogClassificationType = "non-classified";
                }
                else if (i == 2)
                {
                    catalogClassificationType = "non-preferred";
                }*/
                foreach (var item in listWebElement)
                {
                    actualLinkList.Add(item.Text);
                    newSortedList.Add(item.Text);
                }

                newSortedList.Sort();

                if (actualLinkList.Count > 1)
                {
                    alphabetical = true;
                    for (int j = 0; j < actualLinkList.Count - 1; j++)
                    {
                        if (actualLinkList[j] != newSortedList[j])
                        {
                            alphabetical = false;
                            break;
                        }
                    }
                }
                if (alphabetical == false)
                {
                    throw new Exception(string.Format("Displayed data is not in sorted order"));
                }
            }
        }

        public void UserNavigateToTheCatalogItemPageAdminCatalogManagementCurrentCatalogItemsViewAllItemDoubleClickOnAnyItems()
        {
            rq05Driver.SwitchTo().DefaultContent();
            _catalogManagement.Click();

            if (_viewAllItems.Displayed)
            {
                _viewAllItems.Click();
            }
            else
            {
                _currentCatalogItems.Click();
                _viewAllItems.Click();
            }
            rq05Driver.SwitchTo().Frame("RAD_SPLITTER_PANE_EXT_CONTENT_ctl00_cph1_topPane");

            // List<List<string>> titleData = new List<List<string>>();

            if(_rowItemDetails.Count > 0)
            {
                IWebElement data = rq05Driver.FindElement(By.XPath("//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr[9]/td[2]"));
                selectedTitleText = data.Text.ToString().Trim();
                Actions act = new Actions(rq05Driver);
                act.DoubleClick(data).Perform();
            }       
            
            rq05Driver.SwitchTo().DefaultContent();
            rq05Driver.SwitchTo().Frame(rq05Driver.FindElement(By.XPath("//td[@class='rwWindowContent rwExternalContent']/iframe")));
        }

        public void UserNavigateToTheCatalogItemPageAdminCatalogManagementCurrentCatalogItemsViewAllItemDoubleClickOnAnyItemsArchive()
        {
            rq05Driver.SwitchTo().DefaultContent();
            _catalogManagement.Click();

            if (_viewAllItems.Displayed)
            {
                _viewAllItems.Click();
            }
            else
            {
                _currentCatalogItems.Click();
                _viewAllItems.Click();
            }
            rq05Driver.SwitchTo().Frame("RAD_SPLITTER_PANE_EXT_CONTENT_ctl00_cph1_topPane");
            
            if (_rowItemDetails.Count > 0)
            {
                // for()
                int countNumber = _rowItemDetails.Count;
                IWebElement data = rq05Driver.FindElement(By.XPath("//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr[" + (countNumber - 1) + "]/td[2]"));
                selectedTitleText = data.Text.ToString().Trim();
                Actions act1 = new Actions(rq05Driver);
                act1.DoubleClick(data).Perform();
            }
            else
            {
                throw new Exception(string.Format("Item search grid data is empty"));
            }

            /*selectedTitleText = _captureTitleText.Text.Trim();
            Actions act = new Actions(rq05Driver);
            act.DoubleClick(_doubleClickOn6thRow).Perform();*/
            rq05Driver.SwitchTo().DefaultContent();
            // rq05Driver.SwitchTo().Frame(rq05Driver.FindElement(By.XPath("//iframe[@name='14']")));
            rq05Driver.SwitchTo().Frame(rq05Driver.FindElement(By.XPath("//td[@class='rwWindowContent rwExternalContent']/iframe")));
            
        }

        public void ArchivedDataShouldNotDisplayInTheItemSearchGrid()
        {
             // titleText;
            List<string> lstTitle = new List<string>();
            rq05Driver.SwitchTo().Frame("RAD_SPLITTER_PANE_EXT_CONTENT_ctl00_cph1_topPane");
            if (_rowItemDetails.Count > 0)
            {
                for (int i = 0; i < _rowItemDetails.Count; i++)
                {
                    //IWebElement data = rq05Driver.FindElement(By.XPath("//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr[1]/td[2]"));
                    //selectedTitleText = data.Text.ToString().Trim();

                    IWebElement titleData = rq05Driver.FindElement(By.XPath("//div[@id='ctl00_cph1_Grid1_GridData']//tbody/tr[" + (i + 1) + "]/td[2]"));
                    string titleText = titleData.Text.ToString().Trim();
                    // string titleDataNew = titleData[i].Text.ToString();
                    lstTitle.Add(titleText);
                    if (lstTitle[i] == selectedTitleText)
                    {
                        throw new Exception(string.Format("Archived data is displaying in the item search grid"));
                    }

                }
               
            }
            else
            {
                throw new Exception(string.Format("Item search grid data is empty"));
            }
        }
    }
}
