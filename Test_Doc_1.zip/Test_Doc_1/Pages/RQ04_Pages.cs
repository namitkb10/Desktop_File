﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using SpecFlowBDD_22.CommonClass;
using SpecFlowBDD_22.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.Pages
{
    public class RQ04_Pages
    {
        public IWebDriver rq04Driver;

        ClassCommon cc = new ClassCommon();

        RQ01_Pages rq01pages;
        WaitManager wm;

        [FindsBy(How = How.Id, Using = "ctl00_cph1_FuzzySearch")]
        public IWebElement _chkBoxFuzzySearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_HistorySearch")]
        public IWebElement _chkBoxHistorySearch { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='rtsTxt' and text()='Visibility']")]
        public IWebElement _btnVisibility { get; set; }

        //==========================================================================================================
        [FindsBy(How = How.XPath, Using = "//span[@class='rtsTxt' and contains(text(), 'AD Property')]")]
        public IWebElement _btnADProperty { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ctl00_cph1_Conditions1_viewProperty']//span[@class='rtbText' and text()='Add Condition']")]
        public IWebElement _btnAddCondition { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_gvCurrentProperty_ctl00_ctl04_txtPropertyValue")]
        public IWebElement _inputCityValue { get; set; }

        [FindsBy(How = How.Id, Using = "//input[@id='ctl00_cph1_Conditions1_ddlADAttributeClass_Input']")]
        public IWebElement _ddlSelectedCity { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_txtADAttribValue")]
        public IWebElement _inputCityTextBox { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_btnADAttribSearch")]
        public IWebElement _buttonSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_gvPropertySearch_ctl00_ctl04_columnSelectCheckBox")]
        public IWebElement _chkBoxPopUpCity { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='rtbWrap']//span[@class='rtbText' and text()='Select']")]
        public IWebElement _buttonSelect { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='rtCloseButton']")]
        public IWebElement _buttonClose { get; set; }

        //-------------------------------------------------------------

        [FindsBy(How = How.Id, Using = "ctl00_cph1_Conditions1_gvCurrentProperty_ctl00_ctl04_CurrentPropertySelectSelectCheckBox")]
        public IWebElement _chkBoxCity { get; set; }

        


        //==========================================================================================================
        public RQ04_Pages(IWebDriver rDriver)
        {
            rq04Driver = rDriver;
            PageFactory.InitElements(rDriver, this);
        }

        public void VerifyUserAbleToSelectTheCity()
        {
            _btnADProperty.Click();
            _btnAddCondition.Click();

            /*if (_ddlSelectedCity.GetAttribute("value") != "City")
            {
                throw new Exception(string.Format("Selected Value is not city"));
            }*/
            _inputCityTextBox.SendKeys(cc.getDataFromFile("visibilityCity"));

            _buttonSearch.Click();

            _chkBoxPopUpCity.Click();


            Thread.Sleep(1000);
            _buttonSelect.Click();

            Thread.Sleep(1000);
            _buttonClose.Click();

            Thread.Sleep(1000);
            _chkBoxCity.Click();
            //Till here it is working

        }
    }
}
