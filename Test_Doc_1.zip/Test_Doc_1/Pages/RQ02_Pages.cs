﻿using Dynamitey.DynamicObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using SpecFlowBDD_22.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecFlowBDD_22.Pages
{
    public class RQ02_Pages
    {
        public IWebDriver rq02Driver;

        [FindsBy(How = How.Id, Using = "ctl00_cph1_TitleSearch")]
        public IWebElement _chkBoxTitleSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_BriefDescriptionSearch")]
        public IWebElement _chkBoxBriefDescriptionSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_FullDescriptionSearch")]
        public IWebElement _chkBoxFullDescriptionSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_KeywordSearch")]
        public IWebElement _chkBoxKeywordSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_AdvancSearch")]
        public IWebElement _chkBoxEnableAdvancSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_CatalogClassification")]
        public IWebElement _chkBoxCatalogClassification { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_DisplayCatalogClassification")]
        public IWebElement _chkBoxDisplayCatalogClassification { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_FuzzySearch")]
        public IWebElement _chkBoxFuzzyLogicSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cph1_HistorySearch")]
        private IWebElement _chkBoxHistorySearch { get; set; }

        [FindsBy(How = How.ClassName, Using = "rtbIn")]
        private IWebElement _saveButton { get; set; }

        public RQ02_Pages(IWebDriver rDriver)
        {
            rq02Driver = rDriver;
            PageFactory.InitElements(rDriver, this);
        }

        // Scenario: @RQ02_FA-30_tag1

        public void VerifyAllBasicSearchTermsToDisplay()
        {
            IJavaScriptExecutor jse = (IJavaScriptExecutor)rq02Driver;
            jse.ExecuteScript("window.scrollBy(0,450)", "");

            bool flag = (_chkBoxTitleSearch.Displayed && _chkBoxBriefDescriptionSearch.Displayed && _chkBoxFullDescriptionSearch.Displayed && _chkBoxKeywordSearch.Displayed);
            Thread.Sleep(1000);
            if (flag)
            {
               // Assert.True(flag);
               Console.WriteLine("Displaying all the basic search term checkbox");
            }
            else
            {
                throw new Exception(string.Format("Basic search term checkbox not displaying"));
            }
        }

        public void VerifyAllAdvanceSearchTermsToDisplay()
        {

            bool flag = (_chkBoxEnableAdvancSearch.Displayed && _chkBoxCatalogClassification.Displayed && _chkBoxDisplayCatalogClassification.Displayed && _chkBoxFuzzyLogicSearch.Displayed && _chkBoxHistorySearch.Displayed);
            Thread.Sleep(1000);
            if (flag)
            {
                // Assert.True(flag);
                Console.WriteLine("Displaying all the advance search term checkbox");
            }
            else
            {
                throw new Exception(string.Format("Advance search term checkbox not displaying"));
            }
        }

        // Scenario: @RQ02_FA-30_tag2

        public void VerifyTitleSearchTermsToDisplay()
        {

            bool flag = _chkBoxTitleSearch.Displayed;
            Thread.Sleep(1000);
            if (flag)
            {
                Assert.True(flag);
                Console.WriteLine("Displaying Title search term checkbox");
            }
            else
            {
                throw new Exception(string.Format("Title search term checkbox not displaying"));
            }
        }

        public void VerifyTitleSearchTermsEnabledAndCheckedByDefault()
        {

            AssertionManager.Checked(_chkBoxTitleSearch);
            /*if(!_chkBoxTitleSearch.Selected && _chkBoxTitleSearch.Enabled)
            {
                _chkBoxTitleSearch.Click();

            }
            else
            {

            }

            Thread.Sleep(1000);*/

            /*if (_chkBoxTitleSearch.Selected)
            {
                //Assert.True(flag);
                Console.WriteLine("Displaying Title search term is Enabled and By default checked");
            }
            else
            {
                throw new Exception(string.Format("Title search term is either not checked or not enabled"));
            }*/
        }

        public void VerifyTitleSearchTermsIsUncheck()
        {
            if (!_chkBoxTitleSearch.Selected)
            {
                // _chkBoxTitleSearch.Click();
                Console.WriteLine("Displaying Title search term is unchecked");
            }
            else
            {
                throw new Exception(string.Format("Title search term is checked"));

            }
        }

        public void VerifyTitleSearchTermsClickAndUncheck()
        {
            if (_chkBoxTitleSearch.Selected)
            {
                _chkBoxTitleSearch.Click();
                Console.WriteLine("Displaying Title search term is unchecked");
            }
        }

        public void VerifyTitleSearchTermsClickAndCheck()
        {
            if (!_chkBoxTitleSearch.Selected)
            {
                _chkBoxTitleSearch.Click();
                Console.WriteLine("Displaying Title search term is click & Checked");
            }
            else
            {
                throw new Exception(string.Format("Title search term is already Checked"));

            }
        }

        public void VerifyTitleSearchTermsIsChecked()
        {
            if (_chkBoxTitleSearch.Selected)
            {
               Console.WriteLine("Displaying Title search term is Checked");
            }
            else
            {
                throw new Exception(string.Format("Title search term is not Checked"));

            }
        }

        // Scenario: @RQ02_FA-30_tag3
        public void VerifyBasicSearchTermsToDisplayAndEnable()
        {
            bool flag = (_chkBoxBriefDescriptionSearch.Displayed && _chkBoxFullDescriptionSearch.Displayed && _chkBoxKeywordSearch.Displayed && _chkBoxBriefDescriptionSearch.Enabled && _chkBoxFullDescriptionSearch.Enabled && _chkBoxKeywordSearch.Enabled);
            Thread.Sleep(1000);
            if (flag)
            {
                Console.WriteLine("Displayed and enabled Brief, Full & Keyword search term checkbox");
            }
            else
            {
                throw new Exception(string.Format("Brief Description, Full Description & Keyword search term is either not displaying or not enabled "));
            }
        }

        public void VerifyBasicSearchTermsIsUnchecked()
        {
            if(_chkBoxBriefDescriptionSearch.Selected)
            {
                _chkBoxBriefDescriptionSearch.Click();
            }

            if (_chkBoxFullDescriptionSearch.Selected)
            {
                _chkBoxFullDescriptionSearch.Click();
            }

            if (_chkBoxKeywordSearch.Selected)
            {
                _chkBoxKeywordSearch.Click();
            }

            bool flag = (!_chkBoxBriefDescriptionSearch.Selected && !_chkBoxFullDescriptionSearch.Selected && !_chkBoxKeywordSearch.Selected);
            Thread.Sleep(1000);
            if (flag)
            {
                //Assert.True(flag);
                Console.WriteLine("Brief, Full & Keyword search term checkbox is not checked");
            }
            else
            {
                throw new Exception(string.Format("Brief Description, Full Description & Keyword search term, either of them is checked"));
            }
        }

        public void VerifyBasicSearchTermsIsClickedAndChecked()
        {
            if(!_chkBoxBriefDescriptionSearch.Selected)
            {
                _chkBoxBriefDescriptionSearch.Click();
            }
            if (!_chkBoxFullDescriptionSearch.Selected)
            {
                _chkBoxFullDescriptionSearch.Click();
            }
            if (!_chkBoxKeywordSearch.Selected)
            {
                _chkBoxKeywordSearch.Click();
            }

            bool flag = (_chkBoxBriefDescriptionSearch.Selected && _chkBoxFullDescriptionSearch.Selected && _chkBoxKeywordSearch.Selected);
            Thread.Sleep(1000);
            if (flag)
            {
                //Assert.True(flag);
                Console.WriteLine("Brief, Full and Keyword search term checkbox is clicked & Checked");
            }
            else
            {
                throw new Exception(string.Format("Brief Description, Full Description & Keyword search term, either of them is Unchecked"));
            }
        }

        public void VerifyBasicSearchTermsIsChecked()
        {
            bool flag = (_chkBoxBriefDescriptionSearch.Selected && _chkBoxFullDescriptionSearch.Selected && _chkBoxKeywordSearch.Selected);
            Thread.Sleep(1000);
            if (flag)
            {
                //Assert.True(flag);
                Console.WriteLine("Brief, Full and Keyword search term checkbox is Checked");
            }
            else
            {
                throw new Exception(string.Format("Brief Description, Full Description & Keyword search term, either of them is Unchecked"));
            }
        }

        public void VerifyBasicSearchTermsIsClickedAndUnchecked()
        {
            if (_chkBoxBriefDescriptionSearch.Selected)
            {
                _chkBoxBriefDescriptionSearch.Click();
            }
            if (_chkBoxFullDescriptionSearch.Selected)
            {
                _chkBoxFullDescriptionSearch.Click();
            }
            if (_chkBoxKeywordSearch.Selected)
            {
                _chkBoxKeywordSearch.Click();
            }

            bool flag = (!_chkBoxBriefDescriptionSearch.Selected && !_chkBoxFullDescriptionSearch.Selected && !_chkBoxKeywordSearch.Selected);
            Thread.Sleep(1000);
            if (flag)
            {
                // Assert.True(flag);
                Console.WriteLine("Brief, Full and Keyword search term checkbox is click & Unchecked");
            }
            else
            {
                throw new Exception(string.Format("Brief Description, Full Description & Keyword search term, either of them is Checked"));
            }
        }

        /*public void VerifyBasicSearchTermsIsUnchecked()
        {
            bool flag = (!_chkBoxBriefDescriptionSearch.Selected && !_chkBoxFullDescriptionSearch.Selected && !_chkBoxKeywordSearch.Selected);
            Thread.Sleep(1000);
            if (flag)
            {
                // Assert.True(flag);
                Console.WriteLine("Brief, Full and Keyword search term checkbox is click & Unchecked");
            }
            else
            {
                throw new Exception(string.Format("Brief Description, Full Description & Keyword search term, either of them is Checked"));
            }
        }*/

        // @RQ02_FA-30_tag4
        public void VerifyEnableAdvanceSearchOptionsIsDisplayedAndEnabled()
        {
            bool flag = (_chkBoxEnableAdvancSearch.Displayed && _chkBoxEnableAdvancSearch.Enabled);

            Thread.Sleep(1000);
            if (flag)
            {
                Assert.True(flag);
                Console.WriteLine("Enable Advance Search Options checkbox is displayed & Enabled");
            }
        }

        public void AllSearchTermOptionsareEnabled()
        {
            if ((_chkBoxTitleSearch.Enabled) && (_chkBoxBriefDescriptionSearch.Enabled) && (_chkBoxKeywordSearch.Enabled) && (_chkBoxFullDescriptionSearch.Enabled))
            {
                Console.WriteLine("All advance search options are Disabled");
            }
            else
            {
                throw new Exception(string.Format("All advance search options are Enable"));
            }
        }

        public void VerifyEnableAdvanceSearchOptionsIsChecked()
        {
            bool flag = (_chkBoxEnableAdvancSearch.Selected);

            Thread.Sleep(1000);
            if (flag)
            {
                Assert.True(flag);
                Console.WriteLine("Enable Advance Search Options checkbox is Checked by default");
            }
        }
        public void VerifyOnByDefaultCheckOnEnableAdvanceSearchOptionsBasicSearchTermIsEnabled()
        {
            bool flag = (_chkBoxTitleSearch.Enabled && _chkBoxBriefDescriptionSearch.Enabled && _chkBoxFullDescriptionSearch.Enabled && _chkBoxKeywordSearch.Enabled);
            Thread.Sleep(1000);
            if (flag)
            {
                Assert.True(flag);
                Console.WriteLine("Be default Enable Advance Search Options\" is checked & all the basic search term checkbox is enabled");
            }
        }

        public void VerifyEnableAdvanceSearchOptionsIsClickAndUnchecked()
        {
            if (_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
            }
            bool flag = (!_chkBoxEnableAdvancSearch.Selected);

            Thread.Sleep(1000);
            if (flag)
            {
                Assert.True(flag);
                Console.WriteLine("Enable Advance Search Options checkbox is click and Unchecked");
            }
        }

        public void VerifyOnClickAndUncheckOfEnableAdvanceSearchOptionsBasicSearchTermIsEnabled()
        {
            if (_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
            }
                bool flag = (_chkBoxTitleSearch.Enabled && _chkBoxBriefDescriptionSearch.Enabled && _chkBoxFullDescriptionSearch.Enabled && _chkBoxKeywordSearch.Enabled);
                Thread.Sleep(1000);
                if (flag)
                {
                    Assert.True(flag);
                    Console.WriteLine("Enable Advance Search Options\" is Unchecked & all the basic search term checkbox is enabled");
                }
        }

        // @RQ02_FA-30_tag5

        public void AllEnableAdvanceSearchOptionsareEnabled()
        {
            if ((_chkBoxCatalogClassification.Enabled)  && (_chkBoxFuzzyLogicSearch.Enabled) && (_chkBoxHistorySearch.Enabled))
            {
                Console.WriteLine("All advance search options are enabled");


            }
            else
            {
                throw new Exception(string.Format("All advance search options are enabled"));
            }

        }

        public void AllEnableAdvanceSearchOptionsareUnchecked()
        {
            if ((!_chkBoxCatalogClassification.Selected) && (!_chkBoxFuzzyLogicSearch.Selected) && (!_chkBoxHistorySearch.Selected))
            {
                Console.WriteLine("All advance search options are Unchecked by default");


            }
            else
            {
                throw new Exception(string.Format("All advance search options are not unchecked by defalut"));
            }

        }

        public void AllEnableAdvanceSearchOptionsareDisabled()
        {
            if ((!_chkBoxCatalogClassification.Enabled) && (!_chkBoxFuzzyLogicSearch.Enabled) && (!_chkBoxHistorySearch.Enabled))
            {
                Console.WriteLine("All advance search options are Disabled");


            }
            else
            {
                throw new Exception(string.Format("All advance search options are Enable"));
            }

        }

        public void VerifyEnableAdvanceSearchOptionsIsDisplayedAndEnabled_1()
        {
            bool flag = (_chkBoxEnableAdvancSearch.Displayed && _chkBoxEnableAdvancSearch.Enabled);

            Thread.Sleep(1000);
            if (flag)
            {
                Assert.True(flag);
                Console.WriteLine("Enable Advance Search Options checkbox is displayed & Enabled");
            }
        }

        public void VerifyEnableAdvanceSearchOptionsIsChecked_1()
        {
            bool flag=false;
            if(!_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
                flag = _chkBoxEnableAdvancSearch.Selected;
            }

            Thread.Sleep(1000);
            if (flag)
            {
                Assert.True(flag);
                Console.WriteLine("Enable Advance Search Options checkbox is Checked by default");
            }
        }

        public void VerifyOnCheckOfEnableAdvanceSearchOptionsOtherCheckBoxShouldDisplayAndEnable()
        {
            //bool flag = false;
            if (!_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
            }
                       
            Thread.Sleep(1000);
            if (_chkBoxEnableAdvancSearch.Selected)
            {
                bool flag1 = (_chkBoxCatalogClassification.Displayed && _chkBoxFuzzyLogicSearch.Displayed && _chkBoxHistorySearch.Displayed && _chkBoxCatalogClassification.Enabled && _chkBoxFuzzyLogicSearch.Enabled && _chkBoxHistorySearch.Enabled);
                Thread.Sleep(1000);
                if (flag1)
                {
                    Assert.True(flag1);
                    Console.WriteLine("On Check Of \"Enable Advance search options\" other checkBox \"CatalogClassification\", \"Fuzzy Logic\", \"History Search\" is displaying");
                }
            }
        }

        public void VerifyOnCheckOfEnableAdvanceSearchOptionsOtherCheckBoxShouldByDefaultUnchecked()
        {
            bool flag = false;
            if (!_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
                flag = _chkBoxEnableAdvancSearch.Selected;
            }

            Thread.Sleep(1000);
            if (flag)
            {
                bool flag1 = (!_chkBoxCatalogClassification.Selected && !_chkBoxFuzzyLogicSearch.Selected && !_chkBoxHistorySearch.Selected);
                Thread.Sleep(1000);
                if (flag1)
                {
                    Assert.True(flag1);
                    Console.WriteLine("On Check Of \"Enable Advance search options\" other checkBox \"CatalogClassification\", \"Fuzzy Logic\", \"History Search\" is displaying");
                }
            }
        }

        public void VerifyOnUncheckOfEnableAdvanceSearchOptionsOtherCheckBoxShouldUncheckedAndDisabled()
        {
            bool flag = false;
            if (_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
                flag = (!_chkBoxEnableAdvancSearch.Selected);
            }
            Thread.Sleep(1000);
            if (flag)
            {
                bool flag1 = (!_chkBoxCatalogClassification.Enabled && !_chkBoxDisplayCatalogClassification.Enabled && !_chkBoxFuzzyLogicSearch.Enabled && !_chkBoxHistorySearch.Enabled && !_chkBoxCatalogClassification.Selected && !_chkBoxDisplayCatalogClassification.Selected && !_chkBoxFuzzyLogicSearch.Selected && !_chkBoxHistorySearch.Selected);
                Thread.Sleep(1000);
                if (flag1)
                {
                    Assert.True(flag1);
                    Console.WriteLine("On Uncheck Of \"Enable Advance search options\" all sub-options should be disabled");
                }
            }
        }

        // @RQ02_FA-30_tag6

        public void displayEnableSearchResultDisplayBasedOnClassificationCheckBoxisChecked()
        {
            if (_chkBoxDisplayCatalogClassification.Selected)
            {
                Console.WriteLine("The Enable Search Result Display Based on Classification checkbox is checked");
            }
            else
            {
                throw new Exception(string.Format("The Enable Search Result Display Based on Classification checkbox is not checked"));
            }
        }

        public void EnableSearchResultDisplayBasedOnClassificationCheckBoxisEnabled()
        {
            if (_chkBoxDisplayCatalogClassification.Enabled)
            {
                Console.WriteLine("The Enable Search Result Display Based on Classification checkbox is enabled");
            }
            else
            {
                throw new Exception(string.Format("The Enable Search Result Display Based on Classification checkbox is not enabled"));
            }


        }

        public void EnableSearchResultDisplayBasedOnClassificationCheckBoxisDisabled()
        {
            if (!_chkBoxDisplayCatalogClassification.Enabled)
            {
                Console.WriteLine("The Enable Search Result Display Based on Classification checkbox is disabled");
            }
            else
            {
                throw new Exception(string.Format("The Enable Search Result Display Based on Classification checkbox is not disabled"));
            }


        }
        //========================================End of 6====================below check once===============

        public void VerifyEnableAdvanceSearchOptionsIsDisplayedAndEnabled_2()
        {
            bool flag = (_chkBoxEnableAdvancSearch.Displayed && _chkBoxEnableAdvancSearch.Enabled);

            Thread.Sleep(1000);
            if (flag)
            {
                Assert.True(flag);
                Console.WriteLine("Enable Advance Search Options checkbox is displayed & Enabled");
            }
        }

        public void VerifyEnableAdvanceSearchOptionsIsChecked_2()
        {
            bool flag = false;
            if (!_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
                flag = _chkBoxEnableAdvancSearch.Selected;
            }

            Thread.Sleep(1000);
            if (flag)
            {
                Assert.True(flag);
                Console.WriteLine("Enable Advance Search Options checkbox is Checked by default");
            }
        }

        public void VerifyOnCheckOfEnableAdvanceSearchOptionsOnCheckOfCatalogClassificationCheckBoxEnableSearchResultShouldEnable()
        {
            if(!_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
            }
            bool flag = (_chkBoxEnableAdvancSearch.Selected);
            Thread.Sleep(1000);
            if (flag)
            {
                if (!_chkBoxCatalogClassification.Selected)
                {
                    _chkBoxCatalogClassification.Click();
                }
                bool flag1 = (_chkBoxCatalogClassification.Selected);
                Thread.Sleep(1000);
                if (flag1)
                {

                    Assert.True(_chkBoxDisplayCatalogClassification.Enabled);
                    Console.WriteLine("On check Of \"Enable Advance search options\" & On Check of \"Catalog Classification\" \"Enable search result display based on catalog classification\" is enabled");
                }
            }
        }

        public void VerifyOnCheckOfDisplayCatalogClassificationCheckBoxShouldChecked()
        {
            if (!_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
            }
            bool flag = (_chkBoxEnableAdvancSearch.Selected);
            Thread.Sleep(1000);
            if (flag)
            {
                if (!_chkBoxCatalogClassification.Selected)
                {
                    _chkBoxCatalogClassification.Click();
                }
                bool flag1 = (_chkBoxCatalogClassification.Selected);
                Thread.Sleep(1000);
                if (flag1)
                {

                    bool flag2 = (_chkBoxDisplayCatalogClassification.Enabled && !_chkBoxDisplayCatalogClassification.Selected);
                    Thread.Sleep(1000);
                    if (flag2)
                    {
                        _chkBoxDisplayCatalogClassification.Click();
                        Thread.Sleep(1000);
                        bool flag3 = _chkBoxDisplayCatalogClassification.Selected;
                        if (flag3)
                        {
                            Assert.True(_chkBoxDisplayCatalogClassification.Selected);
                            Console.WriteLine("On check Of \"Enable search result display based on catalog classification\", checkBox is checked");
                        }
                    }
                }
            }
        }
        public void VerifyOnUncheckOfDisplayCatalogClassificationCheckBoxShouldUnhecked()
        {
            if (!_chkBoxEnableAdvancSearch.Selected)
            {
                _chkBoxEnableAdvancSearch.Click();
            }
            bool flag = (_chkBoxEnableAdvancSearch.Selected);
            Thread.Sleep(1000);
            if (flag)
            {
                if (_chkBoxCatalogClassification.Selected)
                {
                    _chkBoxCatalogClassification.Click();
                }
                bool flag1 = (!_chkBoxCatalogClassification.Selected);
                Thread.Sleep(1000);
                if (flag1)
                {

                    bool flag2 = (!_chkBoxDisplayCatalogClassification.Enabled);
                    Thread.Sleep(1000);
                    if (flag2)
                    {
                            Assert.True(flag2);
                            Console.WriteLine("On check Of \"Enable search result display based on catalog classification\" checkBox is Unchecked, 'Enable search result display based on catalog classification' should be disable");
                        }
                    }
                }
            }

        public void CheckTheEnableSearchByCatalogClassificationCheckBox()
        {
            if(!_chkBoxCatalogClassification.Selected)
            {
                _chkBoxCatalogClassification.Click();
                Console.WriteLine("Enable Search By Catalog Classification CheckBox Checked");
            }
        }
    }
                
        // @RQ02_FA-30_tag7
        
        // No need to write testcase for this
}
