package test_test

import (
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"
)

var (
	bucketName string = "beacon-infra-staging-us-west-2-incoming-inventory-files"
	folderName string = "38809/"
)

func main() {

}
